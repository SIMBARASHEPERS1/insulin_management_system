    <a href="/" wire:navigate>
        <!-- Hidden when collapsed -->
        <div <?php echo e($attributes->class(["hidden-when-collapsed"])); ?>>
            <div class="flex gap-2">
                <img src="/images/flow.png" width="30" class="mt-1" />
                <span class="font-bold text-3xl mr-3 bg-gradient-to-r from-purple-500 to-pink-300 bg-clip-text text-transparent ">
                   IMS
                </span>
            </div>
        </div>

        <!-- Display when collapsed -->
        <div class="display-when-collapsed hidden mx-5 mt-4 lg:mb-6 h-[28px]">
            <img src="/images/flow.png" width="30" class="h-8" />
        </div>
    </a><?php /**PATH C:\xampp\htdocs\maryui\storage\framework\views/cf27b063788b11450c4e3ffe1580e407.blade.php ENDPATH**/ ?>